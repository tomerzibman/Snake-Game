#########################################
# Programmer: Tomer Zibman
# Date: 21/09/2012
# File Name: snake_template.py
# Description: This program is a template for Snake Game.
# It demonstrates how to move and lengthen the snake.
#########################################
import time
import pygame
from random import randint
from math import sqrt                   # only sqrt function is needed from the math module

pygame.init()
#---------------------------------------#
# Initialize game variables             #
#---------------------------------------#
GAME_TIME = 30          # in seconds
CLOCK_TIME = 5          # in seconds
POISON_TIME = 5         # in seconds
HEIGHT = 600            #screen width
WIDTH  = 800            # screen height
outline=0
score = 0               # game score - always starts from 0
seconds=0               # variable to count seconds played
last_second=0           # variable to check if a second passed
delay=60                # initial main loop delay
showClock=False         # variable to tell whether sand clock is displayed or not
showPoison = False      # variable to tell whether poison is displayed or not
currDirection = 0
#---------------------------------------#
# Create image objects                  #
#---------------------------------------#
screen=pygame.display.set_mode((WIDTH,HEIGHT))
clockI = pygame.image.load('sand.bmp')
clockI = pygame.transform.scale(clockI, (40, 40))
bg = pygame.image.load('bg.bmp')
bg = pygame.transform.scale(bg, (WIDTH, HEIGHT))
appleI = pygame.image.load('apple.bmp')
appleI = pygame.transform.scale(appleI, (40, 40))
poisonI = pygame.image.load('poison.bmp')
poisonI = pygame.transform.scale(poisonI, (40, 40))
snakeI = pygame.image.load('snake_start.bmp')
snakeI = pygame.transform.scale(snakeI, (160, 160))

#---------------------------------------#
# Basic Color definitions               #
#---------------------------------------#
WHITE = (255,255,255)
BLACK = (  0,  0,  0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
hCLR = (0, 255, 255)
bCLR = (0, 0, 255)
tCLR = GREEN
#---------------------------------------#
# Create text objects                   #
#---------------------------------------#
myFont = pygame.font.SysFont('Arial',32,True)           # select the font type, size and make it BOLD
scoreText = myFont.render('SCORE: '+str(score),1, RED)  # create the score text object
timeText = myFont.render('TIME: '+str(seconds),1, RED)  # create the time text object
gameOver = myFont.render('GAME OVER',1, RED)
#---------------------------------------#
# snake's properties                    #
#---------------------------------------#
BODY_SIZE = 10      # snake body radius
HSPEED = 20         # snake horizontal speed step
VSPEED = 20         # snake vertical speed step
#make the snake start moving up
speedX = 0          # current horizontal speed
speedY = -VSPEED    # current vertical speed
# on start, snake has a length of 3, here are the initial 3 x and y coordinates (start at the bottom of the screen)
segx = [int(WIDTH/2.)]*3
segy = [HEIGHT, HEIGHT+VSPEED, HEIGHT+2*VSPEED]
direction = [0] * 3 # 0-up;1-down;2-left;3-right
#---------------------------------------#
# Reset different variables             #
#---------------------------------------#
APPLE_SIZE = 40 # for the apple picture
appleX = 0      # holds the apple x coordinate
appleY = 0      # holds the apple y coordinate
appleR = APPLE_SIZE/2   # approximate apple radius size to check if snake head is hitting the apple
outline = 0
MIN_DISTANCE = appleR + BODY_SIZE # this is the minimum distance from snake head to apple center. if distance is smaller than this value than we have a hi
timeLeft=GAME_TIME  # 30 seconds
clockTimeLeft = 0   # variable to keep count of the remaining time to show the sand clock
poisonTimeLeft = 0  # variable to keep count of the remaining time to show the poison image
firstTime=True
clockX = 0
clockY = 0
poisonX = 0
poisonY = 0
#----------------------------------------------#
# function for resetting game variables        #
# used when user wants to play again           #
#----------------------------------------------#
def restartGame():
    global score
    global seconds
    global segx
    global segy
    global last_second
    global delay
    global start_time
    global speedX
    global speedY
    global timeLeft
    global showClock
    global showPoison
    global direction
    global currDirection
    currDirection=0
    score=0
    segx = [int(WIDTH/2.)]*3
    segy = [HEIGHT, HEIGHT+VSPEED, HEIGHT+2*VSPEED]
    direction = [0]*3
    seconds=0
    last_second=0
    delay=60
    firstTime=True
    print (score)
    speedX = 0
    speedY = -VSPEED
    timeLeft=GAME_TIME
    showClock = False
    showPoison = False
    start_time=pygame.time.get_ticks()

#----------------------------------------------#
# function to show game start page             #
#----------------------------------------------#
def startPage():
    # build the page with pictures and text
    screen=pygame.display.set_mode((WIDTH,HEIGHT))
    screen.fill(BLACK)
    screen.blit(snakeI,(300,200))
    pygame.display.set_caption('Snake Game - By Tomer Zibman')
    gameText = myFont.render('S N A K E - G A M E',1, RED) # render new time value
    creatorText = myFont.render('by: Tomer Zibman',1, GREEN) # render new score value
    keyText = myFont.render('Press \'space bar\' to start',1, BLUE) # render new score value
    screen.blit(gameText, (270,100))
    screen.blit(creatorText, (270,400))
    screen.blit(keyText, (230,450))
    pygame.display.update()
    run_loop=True
    # loop to wait for user key input
    while(run_loop):
        events = pygame.event.get()
        for event in events:
            if (event.type == pygame.KEYDOWN):
                if event.key == pygame.K_SPACE:
                    run_loop=False

#----------------------------------------------#
# function to handle game over page            #
#----------------------------------------------#
def gameOverPage():
    # build the page with pictures and text
    screen=pygame.display.set_mode((WIDTH,HEIGHT))
    screen.fill(BLACK)
    gameOverText = myFont.render('GAME OVER!',1, RED) # render new time value
    scoreText = myFont.render('Your score is: '+str(score),1, GREEN) # render new score value
    keyText = myFont.render('Press \'space bar\' to restart',1, BLUE) # render new score value
    quitText = myFont.render('Press \'q\' to quit game',1, BLUE) # render new score value
    screen.blit(gameOverText, (270,200))
    screen.blit(scoreText, (270,300))
    screen.blit(keyText, (230,450))
    screen.blit(quitText, (230,500))
    pygame.display.update()
    run_loop=True
    # loop to wait for user key input
    while(run_loop):
        events=pygame.event.get()
        for event in events:
            if (event.type == pygame.KEYDOWN):
                if event.key == pygame.K_SPACE:
                    return_key = 0
                    run_loop=False
                if event.key == pygame.K_q:
                    return_key=1
                    run_loop=False
    return return_key

#---------------------------------------#
# function that calculates distance     #
# between two points in coordinate system
#---------------------------------------#
def distance(x1, y1, x2, y2):
    return sqrt((x1-x2)**2 + (y1-y2)**2)    # Pythagorean theorem

#----------------------------------------------#
# function that generates random X,Y           #
#----------------------------------------------#
def generateRandomXY():
    X=randint(60,WIDTH-60)
    Y=randint(60,HEIGHT-60)
    return X,Y
#---------------------------------------#
# function that redraws all objects     #
#---------------------------------------#
def redraw_screen():
    # create score and time objects
    timeText = myFont.render('TIME: '+str(timeLeft),1, RED) # render new time value
    scoreText = myFont.render('SCORE: '+str(score),1, RED) # render new score value
    screen.blit(bg,(0,0))
    # draw the snake
    for i in range(len(segx)):
        if(i==0): # if we draw head
            clr=hCLR # head color
            triangleDraw(segx[0],segy[0],direction[0],clr)
        elif (i == len(segx)-1): # draw tail
            clr=tCLR
            triangleDraw(segx[len(segx)-1],segy[len(segx)-1],direction[len(segx)-1],clr)
        else:
            clr=bCLR # body color
            pygame.draw.circle(screen,clr,(segx[i],segy[i]),BODY_SIZE,outline)

    screen.blit(appleI,(appleX,appleY))
    screen.blit(scoreText, (50,30))
    screen.blit(timeText, (650,30))
    # draw sand clock if enabled
    if(showClock == True):
        screen.blit(clockI,(clockX,clockY))
    # draw poison if enabled
    if(showPoison == True):
        screen.blit(poisonI,(poisonX,poisonY))
    # display must be updated, in order
    # to show the drawings
    pygame.display.update()
#-------------------------------------------------------#
# draw triangle in a specific direction and color       #
#-------------------------------------------------------#
def triangleDraw(x,y,d,c):
    if(d==0): #up triangle
        pygame.draw.polygon(screen, c, [[x-10, y+10], [x, y-10],[x+10, y+10]], outline)
    elif(d==1): #down tri
        pygame.draw.polygon(screen, c, [[x-10, y-10], [x+10, y-10],[x, y+10]], outline)
    elif(d==2): #left tri
        pygame.draw.polygon(screen, c, [[x-10, y], [x+10, y-10],[x+10, y+10]], outline)
    else: #right tri
        pygame.draw.polygon(screen, c, [[x-10, y-10], [x+10, y],[x-10, y+10]], outline)
#---------------------------------------#
# Initialization before main loop       #
#---------------------------------------#
inPlay = True
gameOver = False
print (score)
# call the start page fuction
startPage()
# record the system time (in milliseconds) before entring main loop
start_time=pygame.time.get_ticks()
# reset timeLeft to 30 seconds
timeLeft = GAME_TIME
#---------------------------------------#
# the main program begins here          #
#---------------------------------------#
while inPlay:

    # check for events
    pygame.event.get()
    for event in pygame.event.get():    # check for any events
        if event.type == pygame.QUIT:       # If user clicked close
            exit_flag = True                # Flag that we are done so we exit this loop

    keys = pygame.key.get_pressed()
    # act upon key events
    if keys[pygame.K_LEFT] and speedX != HSPEED:
        speedX = -HSPEED
        speedY = 0
        currDirection = 2#left
    if keys[pygame.K_RIGHT] and speedX!=-HSPEED:
        speedX = HSPEED
        speedY = 0
        currDirection = 3#right
    if keys[pygame.K_UP] and speedY!=VSPEED:
        speedX = 0
        speedY = -VSPEED
        currDirection = 0#up
    if keys[pygame.K_DOWN] and speedY!=-VSPEED:
        speedX = 0
        speedY = VSPEED
        currDirection = 1#down

    direction[0]=currDirection
    # move all segments
    for i in range(len(segx)-1,0,-1):   # start from the tail, and go backwards:
        segx[i]=segx[i-1]               # every segment takes the coordinates
        segy[i]=segy[i-1]               # of the previous one
        direction[i]=direction[i-1]
    # move the head
    if(len(segx) >= 1):
        segx[0] = segx[0] + speedX
        segy[0] = segy[0] + speedY
        if (segx[0]==WIDTH or segx[0]==0): #if head touches left/right edges -> game over
            print('game over')
            gameOver=True
        if (segy[0]==HEIGHT or segy[0]==0): #if head touches top/bottom edges -> game over
            print('game over')
            gameOver=True

    #if snake head touches body -> game over
    for i in range(1,len(segx)):
        if (segx[0]==segx[i] and segy[0]==segy[i]):
            print('game over')
            gameOver=True
    # show the apple for the first time
    if (firstTime==True):
        firstTime=False
        appleX,appleY=generateRandomXY()

    if(showClock == False):
        if(randint(1,1000) < 10):  # 1% chance of showing clock
            showClock = True
            clockX,clockY=generateRandomXY()
            clockTimeLeft = CLOCK_TIME # 5 seconds

    if(showPoison == False):
        if(randint(1,1000) < 20):  # 2% chance of showing poison
            showPoison = True
            poisonX,poisonY=generateRandomXY()
            poisonTimeLeft = POISON_TIME # 5 seconds
    # check if head is hitting an apple
    if(distance(segx[0],segy[0],appleX+appleR,appleY+appleR) <= MIN_DISTANCE):
        # if yes: generate new apple, increase the snake size, increment score, update snake speed if needed
        appleX, appleY=generateRandomXY()
        segx.append(segx[-1])
        segy.append(segy[-1])
        direction.append(currDirection)
        score+=1
        print (score)
        if (score%3==0):
            delay-=5
            if (delay<5):
                delay=5
    #if clock is currently displayed, check if snake head is hitting the sand clock
    if(showClock == True):
        if(distance(segx[0],segy[0],clockX+appleR,clockY+appleR) <= MIN_DISTANCE):
            # if yes: extend game time, remove clock
            showClock = False
            timeLeft += 5 # add 5 more seconds
    #if poison is currently displayed, check if snake head is hitting the poison
    if(showPoison == True):
        if(distance(segx[0],segy[0],poisonX+appleR,poisonY+appleR) <= MIN_DISTANCE):
            #if yes: remove poison, reduce score, reduce snake size, check if score bellow 0 to end game
            showPoison = False
            score -= 1 # reduce 1 point
            segx.pop(len(segx)-1)
            segy.pop(len(segy)-1)
            if(score < 0):
                score = 0
                gameOver = True

    #calculate how many seconds passed since game start
    seconds=(pygame.time.get_ticks()-start_time)/1000
    # if 1 second passed: update game time left
    # and if clock/poison are displayed updater their
    #remaining time
    if(seconds != last_second):
        timeLeft -= 1
        if(timeLeft <= 0):
            gameOver=True
        print('                         '),'Time',seconds
        if(showClock == True):
            clockTimeLeft -= 1
            if(clockTimeLeft == 0):
                showClock = False
        if(showPoison == True):
            poisonTimeLeft -= 1
            if(poisonTimeLeft == 0):
                showPoison = False

    last_second = seconds

    # update the screen
    redraw_screen()
    # short delay
    pygame.time.delay(delay)
    # if gameOver flag is true
    # call game over function and handle
    # user inputs (restart game OR quit)
    if(gameOver == True):
        gameOver=False
        k=gameOverPage()
        if(k==1):
            inPlay=False
        if(k==0):
            restartGame()
# quit pygame
pygame.display.quit()    # always quit pygame when done!
